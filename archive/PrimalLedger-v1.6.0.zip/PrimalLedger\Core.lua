-- PrimalLedger Core
-- Main addon initialization and event handling

local addonName, PL = ...

-- Keybinding localization
BINDING_HEADER_PRIMALLEDGER = "Primal Ledger"

-- Addon namespace
PL.version = "1.6.0"
PL.addonLoaded = false
PL.playerLoggedIn = false

-- Create main frame for event handling
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
eventFrame:RegisterEvent("TRADE_SKILL_SHOW")
eventFrame:RegisterEvent("TRADE_SKILL_UPDATE")
eventFrame:RegisterEvent("CRAFT_SHOW")
eventFrame:RegisterEvent("CRAFT_UPDATE")

-- Event handler
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == addonName then
            PL:OnAddonLoaded()
        end
    elseif event == "PLAYER_LOGIN" then
        PL:OnPlayerLogin()
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, _, spellID = ...
        if unit == "player" then
            PL:OnSpellCast(spellID)
        end
    elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" then
        PL:OnTradeSkillUpdate()
    elseif event == "CRAFT_SHOW" or event == "CRAFT_UPDATE" then
        PL:OnCraftUpdate()
    end
end)

-- Called when addon is loaded
function PL:OnAddonLoaded()
    self.addonLoaded = true
    self:InitializeData()
    self:Print("v" .. self.version .. " loaded. Type /pl to open.")
end

-- Called when player logs in
function PL:OnPlayerLogin()
    self.playerLoggedIn = true
    self:UpdateCurrentCharacter()
    self:CreateMinimapButton()
    self:CreateMainFrame()

    -- Show notification window after a short delay to let data settle
    C_Timer.After(2, function()
        PL:ShowNotificationWindow()
    end)
end

-- Called when player casts a spell
function PL:OnSpellCast(spellID)
    self:CheckCooldownSpell(spellID)
end

-- Called when tradeskill window is shown or updated
function PL:OnTradeSkillUpdate()
    if not self.playerLoggedIn then return end
    local charKey = self:GetCharacterKey()
    self:ScanTradeSkillWindow(charKey)
    self:CreateExportButton()
end

-- Called when craft window (Enchanting) is shown or updated
function PL:OnCraftUpdate()
    if not self.playerLoggedIn then return end
    self:CreateCraftExportButton()
end

-- Print helper
function PL:Print(msg)
    print("|cff00ff00[PrimalLedger]|r " .. msg)
end

-- Slash commands
SLASH_PRIMALLEDGER1 = "/primalledger"
SLASH_PRIMALLEDGER2 = "/pl"
SlashCmdList["PRIMALLEDGER"] = function(msg)
    msg = string.lower(msg or "")

    if msg == "reset" then
        PL:ResetData()
        PL:Print("Data has been reset.")
    elseif msg == "remove" then
        PL:RemoveCurrentCharacter()
    else
        PL:ToggleMainFrame()
    end
end

-- Export addon table
_G["PrimalLedger"] = PL
